
WebUI.openBrowser('')
WebUI.navigateToUrl('https://stg-app.nexmedis.com/forgot-password')
WebUI.setText(findTestObject('ForgotPasswordPage/input_email'), 'suprajal-qa@nexmedis.com')
WebUI.click(findTestObject('ForgotPasswordPage/button_reset'))
WebUI.verifyElementPresent(findTestObject('ForgotPasswordPage/alert_success'), 10)
WebUI.closeBrowser()
