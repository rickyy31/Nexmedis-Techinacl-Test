
WebUI.openBrowser('')
WebUI.navigateToUrl('https://stg-app.nexmedis.com/')
WebUI.setText(findTestObject('LoginPage/input_organization'), 'official_nexmedis')
WebUI.click(findTestObject('LoginPage/button_continue'))
WebUI.verifyElementPresent(findTestObject('LoginPage/input_email'), 10)
WebUI.closeBrowser()
