
WebUI.openBrowser('')
WebUI.navigateToUrl('https://stg-app.nexmedis.com/forgot-password')
WebUI.setText(findTestObject('ForgotPasswordPage/input_email'), '')
WebUI.verifyElementNotClickable(findTestObject('ForgotPasswordPage/button_reset'))
WebUI.closeBrowser()
