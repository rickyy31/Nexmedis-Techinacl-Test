
WebUI.openBrowser('')
WebUI.navigateToUrl('https://stg-app.nexmedis.com/forgot-password')
WebUI.click(findTestObject('ForgotPasswordPage/link_backToLogin'))
WebUI.verifyElementPresent(findTestObject('LoginPage/input_organization'), 10)
WebUI.closeBrowser()
