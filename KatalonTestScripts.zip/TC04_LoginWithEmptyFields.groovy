
WebUI.openBrowser('')
WebUI.navigateToUrl('https://stg-app.nexmedis.com/')
WebUI.setText(findTestObject('LoginPage/input_organization'), 'official_nexmedis')
WebUI.click(findTestObject('LoginPage/button_continue'))
WebUI.setText(findTestObject('LoginPage/input_email'), '')
WebUI.setText(findTestObject('LoginPage/input_password'), '')
WebUI.verifyElementNotClickable(findTestObject('LoginPage/button_login'))
WebUI.closeBrowser()
