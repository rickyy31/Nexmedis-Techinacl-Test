
WebUI.openBrowser('')
WebUI.navigateToUrl('https://stg-app.nexmedis.com/forgot-password')
WebUI.setText(findTestObject('ForgotPasswordPage/input_email'), 'invalid@email.com')
WebUI.click(findTestObject('ForgotPasswordPage/button_reset'))
WebUI.verifyElementPresent(findTestObject('ForgotPasswordPage/alert_error_not_found'), 10)
WebUI.closeBrowser()
